#!/usr/bin/python

# Name: Viren Patel
# Date: 2015-01-20
# File: prot_charge.py
# Desc: A program to compute protein charge

import sys 			# for argv

protseq = sys.argv[1]

charge = -0.002

AACharge = {'C':-0.45, 'D':-0.999, 'E':-0.998, 'H':0.091, 'K':1, 'R':1, 'Y':-0.001}

for aa in protseq:
	if aa in AACharge:
		charge += AACharge[aa]
		print(charge)
