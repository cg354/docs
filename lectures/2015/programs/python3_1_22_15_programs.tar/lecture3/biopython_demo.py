#!/usr/bin/python

# Name: Viren Patel
# Date: 2015-01-22
# File: biopython.pl
# Desc: A program illustrating the use of Biopython

import sys

from Bio import SeqIO

for seq_record in SeqIO.parse(sys.argv[1], "fasta"):
    print(seq_record.id)
#    print("===\n")
#    print(repr(seq_record.seq))
#    print("===\n")
#    print(seq_record.seq)
#    print("===\n")
    print(len(seq_record))

