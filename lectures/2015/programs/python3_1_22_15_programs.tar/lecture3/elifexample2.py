#!/usr/bin/python

dna = raw_input("Enter the DNA sequence: ")

seqsize = len(dna)

if seqsize < 10:
	print("The primer must be > 9 nt")
	if seqsize < 5:
		print("The primer must REALLY be > 9 nt")
elif seqsize < 25:
	print("This size is OK")
else:
	print("This primer is too long")
