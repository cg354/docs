#!/usr/bin/python

# Name: Viren Patel
# Date: 2015-01-22
# File: filerunner.py
# Desc: A python program to list a file with line numbers

import sys

fh = open(sys.argv[1], 'r')

lineNumber = 1

for line in fh:
	print(str(lineNumber) + "\t" + line)
	lineNumber += 1


