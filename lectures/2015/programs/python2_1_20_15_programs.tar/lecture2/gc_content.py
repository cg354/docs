#!/usr/bin/python

# Name: Viren Patel
# Date: 2015-01-20
# File: gc_content.py
# Desc: A program to compute GC content

import sys 			# for argv

fhIn = open(sys.argv[1],'r') 	# open file to read

data = fhIn.read() 		# read the contents of the file

fhIn.close()			# close the file

name = (data.split('\n')[0][1:])		# extract the header
sequence = ''.join(data.split('\n')[1:])	# extract the sequence

print("Name is: " + name)
print("Sequence is: " + sequence)
print("Sequence length is: " + str(len(sequence))) # need to convert length to string

gccount = sequence.count('G')
gccount += sequence.count('C') # note use of +=

print("GC = " + str(float(gccount)/len(sequence)))

