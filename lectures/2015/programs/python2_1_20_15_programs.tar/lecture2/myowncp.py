#!/usr/bin/python

# Name: Viren Patel
# Date: 2015-01-20
# File: myowncp.py
# Desc: A simple program illustrating how to read a file

import sys # for argv

fh = open(sys.argv[1],"r") 	# initialize the file handle
data = fh.read() 	# read the contents of the file
fh.close()		# close the file

fh = open(sys.argv[2],"w")	# initialize the file handle
fh.write(data)
fh.close()

