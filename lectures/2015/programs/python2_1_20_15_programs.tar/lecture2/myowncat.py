#!/usr/bin/python

# Name: Viren Patel
# Date: 2015-01-20
# File: myowncat.py
# Desc: A simple program illustrating how to read a file

import sys # for argv

fh = open(sys.argv[1]) # initialize the file handle

data = fh.read() # read the contents of the file

print data # display the data to the screen

