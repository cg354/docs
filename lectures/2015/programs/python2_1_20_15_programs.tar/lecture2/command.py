#!/usr/bin/python

# Name: Viren Patel
# Date: 2015-01-20
# File: command.py
# Desc: This program demonstrated command line parameters in Python

import sys

print(len(sys.argv))
print(sys.argv)

