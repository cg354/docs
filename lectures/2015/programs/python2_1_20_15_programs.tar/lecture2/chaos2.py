#!/usr/bin/python

# Name: Viren Patel
# Date: 2015-01-20
# File: chaos2.py
# Desc: A simple program illustrating chaotic behavior

import sys

# print("This program illustrates a chaotic function")

x = eval(sys.argv[1]) # index is 1 because ... ??

for i in range(10):
	x = 3.9 * x * (1 - x)
	print(x)

