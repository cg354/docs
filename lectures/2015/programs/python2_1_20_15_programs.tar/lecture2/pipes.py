#!/usr/bin/python

# Name: Viren Patel
# Date: 2015-01-20
# File: pipes.py
# Desc: A simple program illustrating how to read/write using pipes

import sys

data = sys.stdin.read()

print data
